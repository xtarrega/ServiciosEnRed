**NOTAS**

CD/CI youtube https://www.youtube.com/watch?v=6eRkCnFhHRg

https://www.koryschneider.com/tab

[https://cheatsheetseries.owasp.org/cheatsheets/Docker_Security_Cheat_Sheet.html](https://cheatsheetseries.owasp.org/cheatsheets/Docker_Security_Cheat_Sheet.html)


