# Vídeos de Jose Ceuta

Tipos de virus

Troyanos

RansomWare

[Clippers](https://www.welivesecurity.com/la-es/2019/02/08/descubren-primer-malware-clipper-malware-en-google-play/)

xHelper se vuelve a reinstalar al reiniciar de fábrica

## OWASP Top 10 mobile

## Entorno de análisis

Muy interesante

[MobSF](https://github.com/MobSF/Mobile-Security-Framework-MobSF) -- Mobile Security Framework 

En kali linux https://github.com/MobSF/Mobile-Security-Framework-MobSF/blob/master/Dockerfile

Lo he instado mediante compose

## ¿Cuál es más seguro? Android o iOS

iOs

## Análisis estático

1. Identificar el APK

   * AndroGuard

   * Amandroid

   * Androwarm

   * ApkAlalyser

   * APKInspector

   * CFGScanDroid

   * ConDroid

   * DroidLegacy

     Abrir MobSF y 

2. Preparar el entorno y las herramientas

3. Revisar permisos

4. Análisis del manifiesto

5. Verificación de servicios

## Análisis de código descompilado

Aplicación 100sonidos.apk
https://www.modapkdescargar.com/com.soundboard.instant.buttons/apk-download.html

## Permisos

1. ¿Qué dice que hace la app?
2. Qué hace realmente
3. Qué podría hacer
4. ¿La necesito?
5. ¿Cuándo la usaré?

## Análisis dinámico

Me quedo en 30:12 



**NOTAS**

Mirar el siguiente [manual](https://hackpuntes.com/que-es-smali-y-como-parchear-una-aplicacion-android/) para parchear una aplicación con smali



**PERMISOS**

https://www.kaspersky.es/blog/android-permissions-guide/10042/

https://developer.android.com/guide/topics/permissions/overview?hl=es-419

