https://portswigger.net/web-security/sql-injection)

# Burp Suite

foxy proxy

docker dvwa

login

admin/password

User id

1

Usar el Comparador cuando hemos visitado dos páginas para ver las diferencias en HEX y en palabras

Ir a la pestaña decoder

1' OR 1=1 #