1 Descubrir cómo está hecha una web, mediante wappalizer o con whatweb

2 Usar acunetix para scanear webs u otro similar

3 Realizar casos desde https://portswigger.net/web-security/sql-injection#retrieving-hidden-data



Nessus

8089-532E-96EB-6A30-D9CD

