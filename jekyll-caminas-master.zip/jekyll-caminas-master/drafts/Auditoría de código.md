## Auditoría de código

https://player.vimeo.com/video/490668027

Seguridad en Base de datos. Firewall de base de datos

https://www.securityartwork.es/2013/05/23/database-firewalls-introduccion/

