Revisión automática de código fuente:
* IBM Security AppScan Source
* Fortify Static Code Analyzer

Source code analysis tools
https://owasp.org/www-community/Source_Code_Analysis_Tools
OWASP web Security testing guide
https://owasp.org/www-project-web-security-testing-guide/latest/
OWASP Secure Coding Practices
https://owasp.org/www-project-secure-coding-practices-quick-reference-guide/migrated_content

Hacer testeo con BurpSuite
https://openwebinars.net/blog/hacer-testeo-con-burp-suite

Configurar en el navegador el proxy para que todo el tráfico vaya por la herramienta. Está escuchando en 8080 por lo que hay que ir al navegador e ir a preferencias.
owaspbwa
bWapp

|